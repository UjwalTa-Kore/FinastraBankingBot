function currencyFormatter(number, code = 'USD') {
    try {
        return new Intl.NumberFormat('en-US', {
            style: 'currency',
            currency: code,
            minimumFractionDigits: 2,
        }).format(number);
    } catch (err) {
        return (Number(number).toFixed(2)) + " " + code;
    }
}

function isJson(str) {
    try {
        JSON.parse(str);
    } catch (e) {
        return false;
    }
    return true;
}

function getTodaysDate() {
    return getFormattedDate();
}

function getFormattedDate(date){
	var d = (date)? new Date(date):new Date();
    var dd = (d.getDate()<10)?'0'+d.getDate():d.getDate();
	var month = d.getMonth()+1;
	var mm = (month<10)?'0'+month:month;
	return d.getFullYear() + '-' + mm + '-' + dd;
}

function createWebSdkCarouselTemplate(processedData) {
    var message = {
        "type": 'template',
        "payload": {
            "template_type": 'carousel',
            "elements": []
        }
    };

    for (var i = 0; i < processedData.length; i++) {
        var element = {
            "title": processedData[i].title,
            "image_url": processedData[i].image_url,
            "subtitle": processedData[i].subtitle,
            "default_action": {
                "type": "web_url",
                "url": processedData[i].url
            },
            "buttons": [{
                "type": "web_url",
                "url": processedData[i].url,
                "title": "View more"
            }]
        }
        message.payload.elements.push(element);
    }
    return JSON.stringify(message);
}

function createWebSdkQuickRepliesTemplate(text, payload) {
    var message = {
        "type": "template",
        "payload": {
            "template_type": "quick_replies",
            "text": text,
            "quick_replies": []
        }
    };

    for (var i = 0; i < payload.length; i++) {
        var quickReply = {
            "content_type": "text",
            "title": payload[i].title,
            "payload": payload[i].payload
        };

        message.payload.quick_replies.push(quickReply);
    }
    return JSON.stringify(message);
}